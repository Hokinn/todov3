<?php
    // incarcam toate taskurile
    function load_tasks($all = true){
        $data = file_get_contents("database/tasks.json");
        $tasks = json_decode($data, true);
        $t_pages = ceil(count($tasks) / PER_PAGE);
        $c_page = $_GET['page'] ?? 1;

            // pagination
            // per page
            if($all) {
                $tasks = [
                'items' => $tasks,
                'total_pages' => $t_pages, 
                'current_page' => $c_page
            ]; // ne am lasat doar 5 taskuri 

            } else {
                 $tasks = [
                'items' => array_slice($tasks, ($c_page - 1) * PER_PAGE, PER_PAGE),
                'total_pages' => $t_pages, 
                'current_page' => $c_page
            ]; // ne am lasat doar 5 taskuri
            }
            
        return $tasks;
    }
    

    // salvam un task
    function save_task($task){
        $tasks = load_tasks();
        $tasks = $tasks['items'];
        $tasks[] = $task;
        $data = json_encode($tasks, JSON_PRETTY_PRINT);
        file_put_contents("database/tasks.json", $data);
    }
?>