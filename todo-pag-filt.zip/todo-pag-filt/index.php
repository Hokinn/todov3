
<?php
    include 'config.php';
    include 'lib/task.php';
    include 'lib/people.php';
    $tasks = load_tasks(false); // se foloseste return in structura data // am pus false ca sa nu folosim toti parametrii
    $people = load_people();
?>

<?php 
    // prezentam, vivod
    include 'templates/task-list.php';
    include 'templates/task-form.php';
?>