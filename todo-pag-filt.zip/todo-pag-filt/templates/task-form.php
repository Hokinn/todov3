<!-- // datele se vor duce in save.php -->
<form action="save.php" method="POST">
    <input name="title" type="text" placeholder="task tittle">
    <?php include 'templates/people-select.php' ?>
    <hr>
    <button>SAVE</button>
</form>

<!-- // icludem si oamenii
    
 -->