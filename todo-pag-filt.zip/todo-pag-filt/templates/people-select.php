    <select name="employer">
        <option>Select employer</option>
        <?php foreach($people as $person) { ?>
            <option>
                <?php print $person['name']; ?>
                (<?php print $person['job']; ?>)
            </option> 
        <?php } ?>
    </select>