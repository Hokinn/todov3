<!-- // shablon, pentru lista de taskuri -->
<div>
    <h3>Showing tasks (<?php print count($tasks['items']); ?>)</h3>
    <ul>
        <?php foreach($tasks['items'] as $task) { ?>
            <li>
                <input type="checkbox" <?php if($task["status"] == 'Done') { ?>checked<?php } ?>>
                <?php print $task['title']; ?>
                <small>
                    (<?php
                        print $task["created"]; 
                        // p/a: 1) history
                                // today, yesteday, this week, this month
                     ?>)
                </small>
            </li>
        <?php } ?>
    </ul>
    <hr>
    
    <?php for($p = 1; $p <= $tasks['total_pages']; $p++) { ?>
    
    <?php if($p == $tasks['current_page']) { ?>
       <a href="?page=<?php print $p ?>">[<?php print $p ?>]</a>
    <?php } else { ?>
        <a href="?page=<?php print $p ?>"><?php print $p ?></a>
    <?php } ?>    

    <?php } ?>
</div>