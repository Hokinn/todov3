<?php

    const PER_PAGE = 5; // 5 zadaci 

?>