<?php

    $products = [
            [
                "name" => "Product 1",
                "price" => 40000
            ],
            [
                "name" => "Product 2",
                "price" => 30000
            ],
            [
                "name" => "Product 3",
                "price" => 50000
            ]
        ];

        $prices = array_column($products, "price");
        array_multisort($prices, $products);
        var_dump($products);
        // p/a: incercam sa sortam taskurile 
?>